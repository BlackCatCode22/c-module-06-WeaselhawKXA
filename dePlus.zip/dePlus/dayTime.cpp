/*
[dayTime.cpp]
WeaselhawKXA
Lundi 10 octobre 2025
 */
#include <iostream>

class player {
    private:
        int health;
        int atk;
        int def;
        std::string name;
        std::string species;
    public:
    //player();
    void setHealth(int h) {
        health = h;
    }
    int getHealth() {
        return health;
    }
    void setAtk(int a) {
        atk = a;
    }
    int getAtk() {
        return atk;
    }
    void setDef(int d) {
        def = d;
    }
    int getDef() {
        return def;
    }
    void setName(std::string n) {
        name = n;
    }
    std::string getName() {
        return name;
    }
    void setSpec(std::string s) {
        species = s;

    }
    std::string getSpec() {
        return species;
    }

};

class enemy {
    private:
        int health;

    public:


};

int main() {

    return 0;
}