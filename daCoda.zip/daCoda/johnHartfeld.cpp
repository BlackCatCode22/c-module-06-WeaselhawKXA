/* [johnHartfeld.cpp]
    0836901 Mercredi 22 2025
*/
#include <iostream>
#include <fstream>
#include <string>
#include <string_view>
#include <sstream>
#include <vector>

class animal {
    private:
        int age = 0;
        std::string sex;
        std::string species;
        std::string bSeason;
        std::string color;
        int weight = 0;
        std::string pHome;
        std::string name;
    public:
        void setAge(int age) {
            this->age = age;
        }
        int getAge() {
            return this->age;
        }
        void setGender(std::string gender) {
            this->sex = gender;
        }
        std::string getGender() {
            return this->sex;
        }
        void setSpecies(std::string species) {
            this->species = species;
        }
        std::string getSpecies() {
            return this->species;
        }
        void setBSeason(std::string bSeason) {
            this->bSeason = bSeason;
        }
        std::string getBSeason() {
            return this->bSeason;
        }
        void setColor(std::string color) {
            this->color = color;
        }
        std::string getColor() {
            return this->color;
        }
        void setWeight(int weight) {
            this->weight = weight;
        }
        int getWeight() {
            return this->weight;
        }
        void setPHome(std::string pHome) {
            this->pHome = pHome;
        }
        std::string getPHome() {
            return this->pHome;
        }
        void setName(std::string name) {
            this->name = name;
        }
        std::string getName() {
            return this->name;
        }
    //animal();
    void identify(){
        //std::ifstream ifs;
        std::cout << this->age << "\n";
        std::cout << this->species << "\n";
        std::cout << this->bSeason << "\n";
        std::cout << this->color << "\n";
        std::cout << this->weight << "\n";
        std::cout << this->pHome << "\n";
        std::cout << this->name << "\n";
    };

};

class hyena:public animal {
    public:

};

class lion:public animal {
    public:
};

class tiger:public animal {
    public:
};

class bear:public animal {
    public:

};


class zookeeper {
    private:
    std::string name;
    int age = 0;
    std::string gender;

    public:
        void setName(std::string name) {
            this->name = name;
        }
        std::string getName() {
            return this->name;
        }
};

int main() {

    std::fstream file;
    file.open("C:/Users/BE129/daCoda/animalID/arrivinganimals.txt", std::ios::in);
    if (file.is_open()) {
        std::string hipp;
        while (std::getline(file, hipp)) {
            std::cout << hipp << std::endl;
        }
        file.close();
    std::cout << "\n";
    }
/*
    file.open("C:/Users/BE129/daCoda/nuStuff/mu.txt",std::ios::out);
    if (file.is_open()) {
        file << ("4 year old female hyena, born in spring, tan color, 70 pounds, from Friguia Park, Tunisia") << std::endl;
        file << ("12 year old male hyena, born in fall, brown color, 150 pounds, from Friguia Park, Tunisia") << std::endl;
        file << ("4 year old male hyena, born in spring, black color, 120 pounds, from Friguia Park, Tunisia") << std::endl;
        file << ("8 year old female hyena, unknown birth season, black and tan striped color, 105 pounds, from Friguia Park, Tunisia") << std::endl;
        file << ("6 year old female lion, born in spring, tan color, 300 pounds, from Zanzibar, Tanzania") << std::endl;
        file << ("12 year old female lion, born in winter, dark tan color, 375 pounds, from KopeLion, Tanzania") << std::endl;
        file << ("22 year old male lion, born in fall, golden color, 450 pounds, from Zanzibar, Tanzania") << std::endl;
        file << ("4 year old female lion, born in spring, tan and brown color, 275 pounds, from KopeLion, Tanzania") << std::endl;
        file << ("2 year old male tiger, born in spring, gold and tan stripes color, 270 pounds, from Dhaka, Bangladesh") << std::endl;
        file << ("4 year old female tiger, born in spring, black stripes color, 400 pounds, from Dhaka, Bangladesh") << std::endl;
        file << ("18 year old male tiger, born in fall, gold and tan color, 300 pounds, from Bardia, Nepal") << std::endl;
        file << ("3 year old female tiger, born in spring, black stripes color, 285 pounds, from Bardia, Nepal") << std::endl;
        file << ("7 year old male bear, born in spring, brown color, 320 pounds, from Alaska Zoo, Alaska") << std::endl;
        file << ("25 year old female bear, born in spring, black color, 425 pounds, from Woodland park Zoo, Washington") << std::endl;
        file << ("4 year old female bear, born in fall, black color, 355 pounds, from Woodland park Zoo, Washington") << std::endl;
        file << ("4 year old male bear, born in spring, brown color, 405 pounds, from Alaska Zoo, Alaska") << std::endl;
        file << ("");
        file << ("");
        file.close();
    }
    std::cout << "\n";
*/
    animal a;
    a.setAge(4);
    a.setGender("Female");
    a.setSpecies("Hyena");
    a.setBSeason("Spring");
    a.setColor("Tan");
    a.setWeight(70);
    a.setPHome("Friguia Park");
    a.setName("Hyena");
    a.identify();
    std::cout << "\n";

    animal b;
    b.setAge(12);
    b.setGender("Male");
    b.setSpecies("Hyena");
    b.setBSeason("Fall");
    b.setColor("Brown");
    b.setWeight(150);
    b.setPHome("Friguia Park");
    b.setName("Hyena");
    b.identify();
    std::cout << "\n";

    animal c;
    c.setAge(4);

    c.setGender("Male");
    c.setSpecies("Hyena");
    c.setBSeason("Spring");
    c.setColor("Black");
    c.setWeight(120);
    c.setPHome("Friguia Park");
    c.setName("Hyena");
    c.identify();
    std::cout << "\n";

    animal d;
    d.setAge(8);
    d.setGender("Female");
    d.setSpecies("Hyena");
    d.setBSeason("Unknown");
    d.setColor("Black and Tan Striped");
    d.setWeight(105);
    d.setPHome("Friguia Park");
    d.setName("Hyena");
    d.identify();
    std::cout << "\n";

    animal e;
    e.setAge(6);
    e.setGender("Female");
    e.setSpecies("Lion");
    e.setBSeason("Spring");
    e.setColor("Tan");
    e.setWeight(300);
    e.setPHome("Zanzibar");
    e.setName("Lion");
    e.identify();
    std::cout << "\n";



    return 0;
}