/* [johnHartfeld.cpp]
    0836901 Mercredi 22 octobre 2025
*/
#include <iostream>
#include <fstream>
#include <string>
//#include <string_view>
#include <sstream>
//#include <vector>
#include <chrono>
//#include <ctime>
#include <iomanip>
#include <unordered_map>

class animal {
private:
    static int numoAnimals;
    int age = 0;
    std::string sex;
    std::string species;
    std::string bSeason;
    std::string color;
    std::string weight;
    std::string pHome;
    //std::string arrivalDate;
    std::string name;
public:
    void setAge(int age) {
        this->age = age;
    }
    int getAge() {
        return this->age;
    }
    void setGender(const std::string sex) {
        this->sex = sex;
    }
    std::string getGender() {
        return this->sex;
    }
    void setSpecies(std::string species) {
        this->species = species;
    }
    std::string getSpecies() {
        return this->species;
    }
    void setBSeason(std::string bSeason) {
        this->bSeason = bSeason;
    }
    std::string getBSeason() {
        return this->bSeason;
    }
    void setColor(std::string color) {
        this->color = color;
    }
    std::string getColor() {
        return this->color;
    }
    void setWeight(int weight) {
        this->weight = weight;
    }
    std::string getWeight() {
        return this->weight;
    }
    void setPHome(std::string pHome) {
        this->pHome = pHome;
    }
    std::string getPHome() {
        return this->pHome;
    }
    void setName(std::string name) {
        this->name = name;
    }
    std::string getName() {
        return this->name;
    }
    int getPop() {
        return this -> numoAnimals;
    }
    animal(const int age,const std::string &sex, const std::string &name, const std::string &species,
        const std::string &bSeason, const std::string &color,const std::string &weight, const std::string &pHome) {


        this->name = name;
        this->age = age;
        this->sex = sex;
        this->species = species;
        this->bSeason = bSeason;
        this->color = color;
        this->weight = weight;
        this->pHome = pHome;
        numoAnimals++;
    }


    std::string toString() const {
        std::ostringstream oss;
        oss << "\n";
        oss << "Animal Information:\n";
        oss << "-------------------\n";
        oss << "Name: " << name << std::endl;
        oss << "Age: " << age << std::endl;
        oss << "Sex: " << sex << std::endl;
        oss << "Species: " << species << std::endl;
        oss << "BSeason: " << bSeason << std::endl;
        oss << "Color: " << color << std::endl;
        oss << "Weight: " << weight << std::endl;
        oss << "PHome: " << this->pHome << std::endl;
        oss << "\n";

        return oss.str();
        //return this->name;

    }
};
int animal::numoAnimals = 0;

class hyena:public animal {
private:
    static int numoHyena;
public:
    hyena(const int age,const std::string &sex, const std::string &name, const std::string &species,
        const std::string &bSeason, const std::string &color,const std::string &weight, const std::string &pHome)
    :animal(age, sex, name, species, bSeason, color, weight, pHome) {
        numoHyena++;
    }
    static int getNumoHyena() {return numoHyena;}
};
int hyena::numoHyena = 0;

class lion:public animal {
    static int numoLion;
public:
    lion(const int age,const std::string &sex, const std::string &name, const std::string &species,
        const std::string &bSeason, const std::string &color,const std::string &weight, const std::string &pHome)
    :animal(age, sex, name, species, bSeason, color, weight, pHome) {
        numoLion++;
    }
    static int getNumoLion() {return numoLion;}
};
int lion::numoLion = 0;


class tiger:public animal {
    static int numoTiger;
public:
    tiger(const int age,const std::string &sex, const std::string &name, const std::string &species,
        const std::string &bSeason, const std::string &color,const std::string &weight, const std::string &pHome)
    :animal(age, sex, name, species, bSeason, color, weight, pHome) {
        numoTiger++;
    }
    static int getNumoTiger() {return numoTiger;}
};
int tiger::numoTiger = 0;


class bear:public animal {
    static int numoBear;
public:
    bear(const int age,const std::string &sex, const std::string &name, const std::string &species,
        const std::string &bSeason, const std::string &color,const std::string &weight, const std::string &pHome)
    :animal(age, sex, name, species, bSeason, color, weight, pHome) {
        numoBear++;
    }
    static int getNumoBear() {return numoBear;}
};
int bear::numoBear = 0;



/*
class zookeeper {
    private:
    std::string name;
    int age = 0;
    std::string gender;

    public:
        void setName(std::string name) {
            this->name = name;
        }
        std::string getName() {
            return this->name;
        }
    zookeeper(std::string name, std::string gender) {
            this->name = name;
            this->gender = gender;
        }
    std::string toString() const {
            std::ostringstream oss;
            oss << "Zookeeper Credentials:\n";
            oss << "----------------------\n";
            oss << "Name :" << name << std::endl;
            oss << "Age :" << age << std::endl;
            oss << "Gender :" << gender << std::endl;
            oss << "\n";
            return oss.str();
        }

};
*/
int main() {

    std::pmr::unordered_map<std::string, animal*> animalmap;

    //std::pmr::unordered_map<std::string, zookeeper*> zookeepermap;

    std::fstream file;
    file.open("arrivinganimals.txt", std::ios::in);
    if(file.is_open()) {
        std::string line;
        while(getline(file,line)) {
            std::cout << line << std::endl;
            //std::istringstream iss(line);
            std::string s;

        size_t pos = 0;
        std::string delimiter = ", ";

        pos = line.find(delimiter);
        std::string paly = line.substr(0, pos);
        line.erase(0, pos + delimiter.length());
        std::cout << paly << std::endl;

        std::istringstream iss(paly);
            int age;
            std::string year, old, sex, species;

            iss >> age >> year >> old >> sex >> species;

            std::cout << age << sex << species << std::endl;

        pos = line.find(delimiter);
        std::string palo = line.substr(0, pos);
        line.erase(0, pos + delimiter.length());
        std::cout << palo << std::endl;

            std::istringstream iss2(palo);
            std::string born, in, bSeason;

            iss2 >> born >> in >> bSeason;

        pos = line.find(delimiter);
        std::string color = line.substr(0, pos);
        line.erase(0, pos + delimiter.length());
        std::cout << color << std::endl;

        pos = line.find(delimiter);
        std::string weight = line.substr(0, pos);
        line.erase(0, pos + delimiter.length());
        std::cout << weight << std::endl;

        pos = line.find(delimiter);
        std::string location = line.substr(0, pos);
        line.erase(0, pos + delimiter.length());
        std::cout << location << std::endl;

        pos = line.find(delimiter);
        std::string paya = line.substr(0, pos);
        std::string state = line.substr(0, pos);
        line.erase(0, pos + delimiter.length());
        std::cout << paya << std::endl;

            if (species == "hyena") {
                std::string hyenaid = "Hy0" + std::to_string(hyena::getNumoHyena());
                auto* hyaenid = new hyena(0,sex,"",species,bSeason,color,weight,paya);
                animalmap[hyenaid] = hyaenid;
            }

            else if (species == "lion") {
                std::string lionid = "Li0" + std::to_string(lion::getNumoLion());
                auto* felid1 = new lion (0,sex,"",species,bSeason,color,weight,paya);
                animalmap[lionid] = felid1;
            }

            else if (species == "tiger") {
                std::string tigerid = "Ti0" + std::to_string(tiger::getNumoTiger());
                auto* felid2 = new tiger (0,sex,"",species,bSeason,color,weight,paya);
                animalmap[tigerid] = felid2;
            }

            else if (species == "bear") {
                std::string bearid = "Be0" + std::to_string(bear::getNumoBear());
                auto* ursid = new bear (0,sex,"",species,bSeason,color,weight,paya);
                animalmap[bearid] = ursid;
            }



        bear animal(0,sex,"",species,bSeason,color,weight,paya);
        std::cout << animal.toString() << std::endl;
        }
        file.close();
    }else{std::cout << "Unable to open file" << std::endl;}

    /*file.open("C:/Users/BE129/daCoda/nuStuff/nu.txt",std::ios::out);
    if (file.is_open()) {
        file << "Roland, M";
        file.close();
    }*/

    animal* a = animalmap["Hy01"];
    std::cout << a->toString() << std::endl;

    //getPop();

    //zookeeper zookeepermap["Z01"];
    //std::cout << zookeeper.toString();

    //std::cout << animal::numoAnimals << std::endl;

    return 0;
}